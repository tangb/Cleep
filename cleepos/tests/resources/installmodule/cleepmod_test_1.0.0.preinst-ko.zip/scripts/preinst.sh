#!/bin/bash
#touch /tmp/preinst.tmp
exit 130

