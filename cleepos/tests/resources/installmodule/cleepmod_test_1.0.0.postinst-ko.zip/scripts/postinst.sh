#!/bin/bash
#touch /tmp/postinst.tmp
exit 130

