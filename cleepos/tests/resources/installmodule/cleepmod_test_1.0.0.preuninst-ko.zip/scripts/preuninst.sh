#!/bin/bash
#touch /tmp/preuninst.tmp
exit 130

